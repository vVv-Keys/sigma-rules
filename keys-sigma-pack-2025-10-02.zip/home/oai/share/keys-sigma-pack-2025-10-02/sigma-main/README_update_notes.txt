This update pack mirrors the KeysGuard Sigma rules added on 2025-10-02 and includes:
- UAC bypass umbrella rule for auto-elevating binaries.
- ForFiles proxy execution rule.
- ComputerDefaults UAC child process heuristic.
- Registry modification rule for ms-settings/DelegateExecute prep.
- PowerShell AMSI bypass keyword detections (script-block and process creation fallback).
- Ivanti EPMM authentication bypass webserver rule.

A GitHub Actions workflow (.github/workflows/sigma-ci.yml) is included for linting and sigma validation.
