Sigma Update Pack (2025-10-02)
=============================

This archive contains a set of new Sigma rules and a GitHub Actions workflow, ready to be integrated into two different repositories:

1. `sigma-rules-keys` (your personal rules collection)
2. `sigma` (your fork of SigmaHQ)

Folder Structure
----------------

- `sigma-rules-keys/`
  - `windows/process_creation/*.yml` — process creation detections
  - `windows/registry/*.yml` — registry_set detection
  - `windows/powershell/*.yml` — PowerShell script-block and fallback rules
  - `web/iis/*.yml` — webserver detection
  - `.github/workflows/sigma-ci.yml` — CI workflow for linting and validation
  - `CHANGELOG.md` — append to your existing changelog (or create new if absent)

- `sigma-main/`
  - `rules/windows/process_creation/*.yml` — same rules for the upstream layout
  - `rules/windows/registry/*.yml`
  - `rules/windows/powershell/*.yml`
  - `rules-emerging-threats/webserver/*.yml`
  - `.github/workflows/sigma-ci.yml` — CI workflow
  - `README_update_notes.txt` — notes about the update

How to apply the update
-----------------------

1. Clone your repositories if you haven't already:

    ```bash
    git clone YOUR_FORK_URL/vVv-Keys/sigma-rules.git
    git clone YOUR_FORK_URL/vVv-Keys/sigma.git
    ```

2. Copy the files from this archive into the respective repositories. Preserve the folder paths:

    - Files under `sigma-rules-keys/` go into `sigma-rules/sigma-rules-keys/` (create the directory if missing). The `.github/workflows/sigma-ci.yml` belongs in `.github/workflows/` at the repo root.
    - Files under `sigma-main/` go into your `sigma` repo: `rules/…` and `rules-emerging-threats/…`. Place the CI workflow into `.github/workflows/`.

3. Commit and push the changes, for example:

    ```bash
    cd sigma-rules
    git checkout -b feat/keys-pack-2025-10-02
    cp -R path/to/sigma-rules-keys/* .
    git add .
    git commit -m "feat: add KeysGuard Sigma pack (2025-10-02)"
    git push -u origin feat/keys-pack-2025-10-02

    cd ../sigma
    git checkout -b feat/keys-pack-2025-10-02
    cp -R path/to/sigma-main/* .
    git add .
    git commit -m "feat: add KeysGuard Sigma pack (2025-10-02)"
    git push -u origin feat/keys-pack-2025-10-02
    ```

4. Create pull requests in GitHub to merge these branches into their respective default branches.

5. Review the CI results. The included GitHub Actions workflow will run `yamllint` and `sigma-cli` validations on every push or PR.

