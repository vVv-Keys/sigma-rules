## 2025-10-02
- Add UAC bypass umbrella rule for auto-elevating binaries (AppInfo abuse).
- Add ForFiles proxy execution rule (cmd/powershell/mshta/wscript).
- Add ComputerDefaults UAC child process heuristic rule.
- Add registry_set rule for ms-settings / DelegateExecute prep.
- Add PowerShell AMSI bypass keyword detections (script-block + process fallback).
- Add Ivanti EPMM auth-bypass webserver rule (IIS + generic).
- Add GitHub Actions workflow for yamllint + sigma validate.
